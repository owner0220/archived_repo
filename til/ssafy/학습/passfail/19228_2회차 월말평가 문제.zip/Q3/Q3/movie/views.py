from django.shortcuts import render

# 여기에 코드를 작성하시오.